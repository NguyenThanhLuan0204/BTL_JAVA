package N_DT23.service;

import java.util.List;

import N_DT23.entity.ChiTietLoaiSP;

public interface CTLoaiSPService {
    public List<ChiTietLoaiSP> getDSCTLoaiSP();
}
