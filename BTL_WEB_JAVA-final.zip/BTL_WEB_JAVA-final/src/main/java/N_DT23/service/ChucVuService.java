package N_DT23.service;

import java.util.List;

import N_DT23.entity.ChucVu;

public interface ChucVuService {
    public List<ChucVu> getDSChucVu();
}
