package N_DT23.service;

import java.util.List;

import N_DT23.entity.LoaiSanPham;

public interface LoaiSanPhamService {
    public List<LoaiSanPham> getDSLoaiSanPham();
}
