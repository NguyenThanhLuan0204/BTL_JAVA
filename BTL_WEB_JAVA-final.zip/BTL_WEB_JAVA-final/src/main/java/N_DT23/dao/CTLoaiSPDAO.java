package N_DT23.dao;

import java.util.List;

import N_DT23.entity.ChiTietLoaiSP;

public interface CTLoaiSPDAO {
    public List<ChiTietLoaiSP> getDSChiTietLoaiSP();
}
