package N_DT23.config;

import java.util.Random;

public class test123 {

	public static void main(String[] args) {
		 double randomDouble = Math.random();
         randomDouble = randomDouble * 100 + 1;
         int randomInt = (int) randomDouble;
         System.out.println("Random number is : " + randomInt);

	}

}
